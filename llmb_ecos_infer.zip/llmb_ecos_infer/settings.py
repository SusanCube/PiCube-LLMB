import sys

#==============================

MODE_Release               =  0 ##  0 -- Main Entry.
MODE_Release_20250115_PCB  =  1 ##  1 -- PCB Connect check.
MODE_Release_20250115_FULL =  2 ##  2 -- Full Speed.
MODE_Full_Test             =  3 ##  3 -- Full Test.
MODE_Debug                 =  4
MODE_PCB                   =  5 ##  5 -- PCB Connect check.
MODE_FULL                  =  6 ##  6 -- Full Speed.
MODE_Release_20250214_IVCT =  7 ##  7 -- Transfer IVCT
MODE_RandomTest            =  8 ##  8 -- Random Test
MODE_WghtOnly              =  9 ##  9 -- WghtOnly
MODE_BootOnly              = 10 ## 10 -- BootOnly
MODE_Init_SKIP2805         = 11 ## 11 -- Card_Init SKIP2805

if len(sys.argv) > 3:
    MODE = sys.argv[3]
else:
    MODE = 6

DDRSCANLoop = 0

#==============================

Release_MODELIST = [MODE_Release, MODE_Release_20250115_PCB, MODE_Release_20250115_FULL, MODE_Release_20250214_IVCT]
Old_Word_Order_MODELIST = [MODE_Release_20250115_PCB, MODE_Release_20250115_FULL] ## Use 202411291738, Old Word Order
if MODE in Old_Word_Order_MODELIST:
    print(f"MD {MODE} in {Old_Word_Order_MODELIST}")
else:
    print(f"MD {MODE} not in {Old_Word_Order_MODELIST}")

#==============================

TOTAL_GNPU = 64
PILE_NUM = 4
EDGE_NUM = 8
ATTN_NUM = EDGE_NUM * 2

PP = range(PILE_NUM)
#PP = [1]          ## if NOT run all PORT, uncomment this then modify as you need.

EE = range(EDGE_NUM)
#EE = [4,5,6,7]    ## if NOT run all EDGE, uncomment this then modify as you need.

#==============================

RISV_FREQ = 320
GNPU_FREQ = 320
GNPU_FREQ = 300
issuHardAcks = 1
Voc_EN = 1

VERBOSE = 7
VERBOSE = 4
VERBOSE = 1

