import time
from config import *
from pcie_base_task import *
from pcie_llmb_task import *
#from pcie_link_util import *
from pcie_core_func import *
from proc_engn_core import *

class PCIe_CORE(ENGN_CORE, PCIe_LLMB, PCIe_Base):

    def __init__(self, cid):
        PCIe_Base.__init__(self, cid)

