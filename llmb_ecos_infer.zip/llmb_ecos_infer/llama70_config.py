from settings import *
from transformers import AutoTokenizer
import numpy as np

Tokenizer_PATH  = "../icube/llama3_weight/70b_tokenizer"
WGHT_PATH       = "../icube/llama3_weight/Meta-Llama-3-70B-Instruct/recombinationImg"
WGHT_PATH_HEX   = "../icube/llama3_weight/Meta-Llama-3-70B-Instruct/recombinationHex"
MLP_ROUND       = 80
CodeImg         = "../icube/G_agile_Main27_Infer70_202503072041.img"
CodeImg         = "../icube/agile_Test06_GNPU_CMND_202503231545.img"  ## 19RMSNormWght
CodeImg         = "../icube/agile_Test06_GNPU_202503281229.img"
CodeImg         = "../icube/agile_Main28_GNPU_202503302038.img"
CodeImg         = "../icube/agile_Main28_GNPU_epdc_202504060015.img"
CodeImg         = "../icube/agile_Main28C_GNPU_202504142004.img"
Vocabulary      = "../icube/llama3_weight/llama3_70b_embedding_dict/dict.bin"
VocabularyTxt   = "../icube/llama3_weight/llama3_70b_embedding_dict/dict.txt"
VocLen          = 8192
EMBLen          = 128
MLPLen          = 448
FINLen          = 2016
CustomCol       = 4096
SIZE_SPLT       = 4096
LINE_COLS       = 4096
READ_COLS       = 1024
WGHT_SIZE       = 0x84200 # 0x84200 = 0x1084000 // 32

START_TOKEN     = 128000
END_TOKEN       = [128001, 128009]
VocLoad         = 1

MAXLOOP = 32
MAXTOKENLEN = 8192

STEP1Sleep = 0
STEP2Sleep = 0
STEP3Sleep = 0
STEP4Sleep = 0
FINALSleep = 0
ROUNDSleep = 1000
 
SLAV_CODE_BASE       = 0x00001000
SLAV_DATA_BASE       = 0x036d0100
SLAV_WGHT_BASE       = 0x00008000

SLAV_HEAD_BASE       = 0x02952000
SLAV_KBAS_BASE       = 0x029d0100
SLAV_VBAS_BASE       = 0x02c50100

SV_SHARE1_BASE       = 0x02ed0100
SV_SHARE2_BASE       = 0x030d0100
SV_SHARE3_BASE       = 0x032d0100
SV_SHARE4_BASE       = 0x034d0100
SV_SHARE5_BASE       = 0x036d0100

MAST_CODE_BASE       = 0x00010000
MAST_WGHT_BASE       = 0x00080000
MAST_DINP_BASE       = 0x00010000
MAST_DATA_BASE       = 0x00010000
MAST_DOUT_BASE       = 0x00010000

if Voc_EN == 1:
    tokenizer = AutoTokenizer.from_pretrained(Tokenizer_PATH)
    if 1:
        fbin = open(Vocabulary, 'rb')
        array = fbin.read()
        Voc = np.frombuffer(array, dtype=np.float32).reshape(128256,8192).astype(np.float16)
    else:
        ftxt = open(VocabularyTxt, 'r')
        array = ftxt.read().splitlines()
        Voc = np.array(array).reshape(128256,8192)
    n_Voc = len(Voc)
    print(f"n_Voc = {n_Voc}")
else:
    tokenizer = 0
    Voc = []
    n_Voc = 0

NNEX_WRIT_FILE = 'writ_data.img'
NNEX_READ_FILE = 'read_data.img'

LAMA_RISV_PARA = [
        {'ADDR' : 0x00000001 , 'PARA' : 0x02ed0100}, # SHARE1  0
        {'ADDR' : 0x00000002 , 'PARA' : 0x030d0100}, # SHARE2  1
        {'ADDR' : 0x00000003 , 'PARA' : 0x032d0100}, # SHARE3  2
        {'ADDR' : 0x00000004 , 'PARA' : 0x034d0100}, # SHARE4  3
        {'ADDR' : 0x00000005 , 'PARA' : 0x036d0100}, # SHARE5  4
        {'ADDR' : 0x00000006 , 'PARA' : 0x029d0100}, # K_BASE  5
        {'ADDR' : 0x00000007 , 'PARA' : 0x02c50100}, # V_BASE  6
        {'ADDR' : 0x00000008 , 'PARA' : 0x02952000}, # H_BASE  7
        {'ADDR' : 0x00000009 , 'PARA' : 0x00084200}, # W_SIZE  8
        {'ADDR' : 0x0000000a , 'PARA' : 0x00008000}, # K_SIZE  9
        {'ADDR' : 0x0000000b , 'PARA' : 0x00008000}, # V_SIZE 10
        {'ADDR' : 0x0000000d , 'PARA' : 0x00000100}, # Q_GEMM 11
        {'ADDR' : 0x0000000e , 'PARA' : 0x00008100}, # K_GEMM 12
        {'ADDR' : 0x0000000f , 'PARA' : 0x00010100}, # V_GEMM 13
        {'ADDR' : 0x00000010 , 'PARA' : 0x00018100}, # D_EMBD 14
        {'ADDR' : 0x00000011 , 'PARA' : 0x00028100}, # O_GEMM 15
        {'ADDR' : 0x00000012 , 'PARA' : 0x00030100}, # M_RMSN 16
        {'ADDR' : 0x00000013 , 'PARA' : 0x00030200}, # U_GEMM 17
        {'ADDR' : 0x00000014 , 'PARA' : 0x0004c200}, # G_GEMM 18
        {'ADDR' : 0x00000015 , 'PARA' : 0x00068200}, # D_GEMM 19
        {'ADDR' : 0x00000016 , 'PARA' : 0x00000100}, # H_GEMM 20
        {'ADDR' : 0x00000017 , 'PARA' : 0x0000000e}, # U_NNUM 21
        {'ADDR' : 0x00000018 , 'PARA' : 0x0000003f}, # H_NNUM 22
]

LAMA_GNPU_PARA = [
        {'ADDR' : 0x38 , 'PARA' : 0x00002000}, # HIDEN_SIZE
        {'ADDR' : 0x39 , 'PARA' : 0x00000040}, # HIDEN_SIZE_DIV128
        {'ADDR' : 0x3a , 'PARA' : 0x00000080}, # HIDEN_DIM
        {'ADDR' : 0x3b , 'PARA' : 0x00000004}, # HIDEN_WGHT_NMAX
        {'ADDR' : 0x3c , 'PARA' : 0x00007000}, # UPDOWN_SIZE
        {'ADDR' : 0x3d , 'PARA' : 0x000000e0}, # UPDOWN_SIZE_DIV128
        {'ADDR' : 0x3e , 'PARA' : 0x000001c0}, # UPDOWN_DIM
        {'ADDR' : 0x3f , 'PARA' : 0x00000001}, # UPDOWN_WGHT_NMAX
]

LAMA_GNPU_GPTR = [
        {'VECT' : 0x08 , 'SPOT' : 0x00 , 'PARA' : 0x00000800}, # 1/HIDEN_SIZE
        {'VECT' : 0x08 , 'SPOT' : 0x01 , 'PARA' : 0x00002da8}, # 1/sqrt(HIDEN_DIM)
]

