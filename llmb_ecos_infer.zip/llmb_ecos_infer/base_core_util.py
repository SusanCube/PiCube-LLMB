import time
from config import *
from pcie_llmb_task import *

SaveLog = []
LogQuit = []
LogQuitStr = []
for i in SaveLogPILE:
    SaveLog.append([])
    LogQuit.append([])
    LogQuitStr.append([])
    for j in SaveLogEDGE:
        SaveLog[i].append(open(f"SaveLog_{i}_{j}.log", "w"))
        LogQuit[i].append(0)
        LogQuitStr[i].append("")

def hex_str(ds):
    if type(ds) == int:
        return hex(ds)[2:]
    if type(ds) == str:
        return ds
    length = len(ds)
    res = '['
    i = 1
    for d in ds:
        res += hex_str(d)
        if i < length:
            res += ', '
        else:
            res += ']'
        i += 1
    return res

def util_invert16(x):
    y = 0
    for i in range(16):
        t = 1 << i
        if (x & t) != t:
            y |= t
    return y

def util_checksum16(code, verbose=0):
    checksum = 0
    i = 0
    cnt = len(code)
    while cnt > 1:
        checksum += code[i] << 8
        checksum += code[i+1]
        if verbose == 1:
            print(f"cksum {cnt} {hex(checksum)} code {hex(code[i])} {hex(code[i+1])}")
        cnt -= 2
        i += 2
        checksum = checksum & 0xffffffff
    if cnt == 1:
        checksum += code[i]
        if verbose == 1:
            print(f"cksum {cnt} {hex(checksum)} code {hex(code[i])}")
    checksum = checksum & 0xffffffff
    if verbose == 1:
        print(f"cksum {cnt} {hex(checksum)}")
    while checksum >= (1 << 16):
        checksum = (checksum >> 16) + (checksum & 0xFFFF)
    if verbose == 1:
        print(f"cksum {cnt} {hex(checksum)}")
    checksum = util_invert16(checksum)
    if verbose == 1:
        print(f"cksum {hex(checksum)}")
    return checksum

def util_read_from_img(fname):
    if FakePcie:
        ls = [11, 22, 33, 44, 55, 66, 77, 88]
    else:
        rf = open(f"{fname}", "rb")
        ls = rf.read()
        rf.close()
    ls = list(ls)
    return ls

def util_alignment(ls, ALIGN=4, tail=0):
    leng = len(ls)
    left = leng % (ALIGN)
    #self.DEBUG4(f"util_alignment    {leng} + {left} = {leng+left} bytes")
    if left > 0:
        ls += [tail]*(ALIGN-left)
    ols = []
    i = 0
    #self.DEBUG4(f"util_alignment    {int((leng+left)/ALIGN)} works")
    while (i<int((leng+left)/ALIGN)):
        tmp = 0
        for j in range(ALIGN):
            tmp = (tmp << 8) + ls[i*ALIGN+(ALIGN-1-j)]
        ols.append(tmp)
        i += 1
    #self.DEBUG4(f"total {i} word")
    return ols

## convert [word list] to [[byte list]]
def parse_readBack(readBack):
    c = []
    for i in PP:
        cc = []
        for j in EE:
            d = readBack[8*i+j]
            cc.append(d)
        c.append(cc)
    return c

## [byte list]
## edges   : if all of edges True, then True
## vars    : if any of vars True, then True
## stopVal : stopVal == 0, then ignore stopVal
def edge_confirm(edges, vals, stopVal=0):
    pass_flag = 1
    for edgeInx in EE:
        passF = 0
        for val in vals:
            if (edges[edgeInx-E0] & val) == val:
                passF = 1
        if stopVal != 0 and (edges[edgeInx-E0] & stopVal) == stopVal:
            pass_flag = -1
            break
        if (passF == 0):
            pass_flag = 0
            break
        #self.DEBUG4(f"{edgeInx} {hex(edges[edgeInx-E0])} {hex(val)}")
    return pass_flag

def edge_confirm_all_not_equal(edges, vals, stopVal=0):
    flag = 1
    for edgeInx in EE:
        edgeFlag = 1
        for val in vals:
            if (edges[edgeInx-E0] & val) == val:
                edgeFlag = 0
        if stopVal != 0 and (edges[edgeInx-E0] & stopVal) == stopVal:
            flag = -1
            break
        if (edgeFlag == 0):
            flag = 0
            break
        #self.DEBUG4(f"{edgeInx} {hex(edges[edgeInx-E0])} {hex(val)}")
    return flag

## [[byte list]]
## piles   : if all of piles True, then True
## vars    : if any of vars True, then True
## stopVal : stopVal == 0, then ignore stopVal
def pile_confirm(piles, vals, stopVal=0):
    pass_flag = 1
    for pile in piles:
        #self.DEBUG4(pile)
        ret = edge_confirm(pile, vals, stopVal)
        if ret == 0:
            pass_flag = 0
            break
        if ret <  0:
            pass_flag = -1
            break
        #self.DEBUG4(pass_flag)
    return pass_flag

def pile_confirm_all_not_equal(piles, vals, stopVal=0):
    flag = 1
    for pile in piles:
        #self.DEBUG4(pile)
        ret = edge_confirm_all_not_equal(pile, vals, stopVal)
        if ret == 0:
            flag = 0
            break
        if ret <  0:
            flag = -1
            break
        #self.DEBUG4(flag)
    return flag

## DUMP 2805 log
def PILE_PRINT_LOOP(pcie, end=""):
    pile_print_reset()
    while pile_print_quit() != 1:
        readBack = pcie.tpem_icfg_tpes(0xa)
        piles = parse_readBack(readBack)
        pile_print(piles, end)

def pile_print(piles, end=""):
    for i in SaveLogPILE:
        for j in SaveLogEDGE:
            d = piles[i][j]
            ch = chr(d)
            LogQuitStr[i][j] = LogQuitStr[i][j] + ch
            if end.startswith(LogQuitStr[i][j]) == 0:
                LogQuitStr[i][j] = ""
            if end != "" and end == LogQuitStr[i][j]:
                LogQuit[i][j] = 1
            SaveLog[i][j].write(ch)

def pile_print_quit():
    quit = 1
    for pile in LogQuit:
        for edge in pile:
            if edge == 0:
                quit = 0
    return quit

def pile_print_reset():
    for i in SaveLogPILE:
        for j in SaveLogEDGE:
            LogQuit[i][j] = 0
## DUMP end

def Agile_Write(fname, addr, rows, cols):
    PCIeWrap_WRIT_DDRC(fname, addr, rows, cols)

def Agile_Read(fname, addr, rows, cols, RdStep=0x3fffffff):
    PCIeWrap_READ_DDRC(fname, addr, rows, cols, RdStep)

def gets_cube_code(code):
    addr = str(codeAddr)
    codeSize = len(code)
    size = str(codeSize)
    lead = "W " + addr + " " + size + "\r"
    #self.DEBUG4(f"lead: {lead}")
    lead = [ord(c) for c in lead]
    tail = size + "\r"
    #self.DEBUG4(f"tail: {tail}")
    tail = [ord(c) for c in tail]
    hexlead = [hex(c)[2:] for c in lead]
    hexcode = [hex(c)[2:] for c in code]
    hextail = [hex(c)[2:] for c in tail]
    #self.DEBUG4(f"hexlead: {hexlead}")
    #if VERBOSE >= 6:
    #    #self.DEBUG4(f"hexcode: {hexcode}")
    #else:
    #    #self.DEBUG4(f"hexcode: {hexcode[0:16]}")
    #    #self.DEBUG4(f"hexcode: ...")
    #    #self.DEBUG4(f"hexcode: {hexcode[-16:]}")
    #self.DEBUG4(f"hextail: {hextail}")
    full_code = lead + code + tail
    #self.DEBUG4(f"full_code    {len(lead)} + {len(code)} + {len(tail)} = {len(full_code)}")
    full_code = util_alignment(full_code, 4, 0x1b) ## PACK_TO_1WORD, 1b = ESC
    if PACK_TO_8WORD == 1:
        leng = len(full_code)
        left = leng % 8
        if left > 0:
            full_code += [0x1b1b1b1b]*(8-left)
    hexFinal = [hex(c)[2:] for c in full_code]
    #if VERBOSE >= 6:
    #    #self.DEBUG4(f"hexFinal: {hexFinal}")
    #else:
    #    #self.DEBUG4(f"hexFinal: {hexFinal[0:8]}")
    #    #self.DEBUG4(f"hexFinal: ...")
    #    #self.DEBUG4(f"hexFinal: {hexFinal[-8:]}")
    #self.DEBUG4(f"hexFinal: {hexFinal}")
    return full_code

def getInput(flagLog):
    while 1:
        choice = input(flagLog)
        if choice.strip().lower() in [".", "end", "exit"]:
            return -1
        elif choice.strip() == "":
            continue
        elif choice.strip().isalpha():
            continue
        choice = eval(choice)
        break
    return choice

def getInputDefault(flagLog, default):
    while 1:
        choice = input(flagLog % default)
        if choice.strip().lower() in [".", "end", "exit"]:
            return -1
        elif choice.strip() == "":
            if default >= 0:
                return default
            else:
                continue
        elif choice.strip().isalpha():
            continue
        choice = eval(choice)
        break
    return choice

