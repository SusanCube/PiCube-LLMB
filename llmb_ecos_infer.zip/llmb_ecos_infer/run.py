import os
import sys
import time
from agile_infer import *
from threading import Thread
from multiprocessing import Process

if len(sys.argv) >= 2 and sys.argv[1] == 'infer':
    Cards = Agile_Elaberate()
    if 1:
        thread_list = []
        for i in range(len(Cards)):
            p = Thread(target=Cards[i].Agile_Card_Work, args=())
            p.start()
            Cards[i].DEBUG2(f"Thread start {i} p = {p}")
            thread_list.append(p)
        for p in thread_list:
            p.join()
        for p in thread_list:
            stat = p.is_alive()
            Cards[i].DEBUG2(f"Thread {i} stat={stat}")
    else:
        process_list = []
        for i in range(len(Cards)):
            p = Process(target=Cards[i].Agile_Card_Work, args=())
            p.start()
            process_list.append(p)

        for p in process_list:
            p.join()

elif len(sys.argv) >= 2 and sys.argv[1] == 'main':
    Cards = Agile_Elaberate()
    if 1:
        thread_list = []
        for i in range(len(Cards)):
            p = Thread(target=Cards[i].Agile_Card_Main, args=())
            p.start()
            Cards[i].DEBUG2(f"Thread start {i} p = {p}")
            thread_list.append(p)
        for p in thread_list:
            p.join()
        for p in thread_list:
            stat = p.is_alive()
            Cards[i].DEBUG2(f"Thread {i} stat={stat}")
    else:
        process_list = []
        for i in range(len(Cards)):
            p = Process(target=Cards[i].Agile_Card_Main, args=())
            p.start()
            process_list.append(p)

        for p in process_list:
            p.join()

