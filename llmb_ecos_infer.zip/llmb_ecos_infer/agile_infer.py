import os
import sys
import time
from config import *
from pcie_core_func import *
#from base_core_util import *
#import transformers
#import torch

class Agile_LLMB(PCIe_CORE):
    def __init__(self, cid):
        PCIe_CORE.__init__(self, cid)
        self.WF = open(f"log{cid}.txt", "w")
        self.T0 = 0

    def T0Init(self):
        t = time.time()
        self.T0 = t

    def DEBUGX(self, Text):
        t = time.time()
        self.WF.write(f"{Text} {t}\n")

    def DEBUGY(self, Text):
        t = time.time()
        self.WF.write(f"{Text} {t} {t-self.T0}\n")
        self.T0Init()

    def Agile_Card_Work(self):
        self.DEBUGX(f"SYS: Agile_Card_Work")
        date = datetime.datetime.now()
        tstr = date.strftime("%Y_%m_%d")
        print("********************************************************************\n")
        print("@" + tstr + "\t\t欢迎使用LLMB_EXPLORER Version1.0\n")
        print("\t\t当前启用模型::" + "DeepSeek R1 70B(FP16)")
        print("@" + tstr + "\t\t当前工作于推理模式\n")
        print("********************************************************************\n")
        print("**请输入提问字符序列，以回车结束**")
        n = 0
        for taps in range(MAXLOOP):
            if True:
                #n = 0
                messages = [{"role": "system","content": "You are a chatbot.",},]
                input_stream = input("\nuser:")
                input_stream = {"role": "user", "content": "wha are you? what can you do?"}
                messages.append(input_stream)
            else:
                messages = [
                    {
                        "role": "system",
                        "content": "You are a pirate chatbot who always responds in pirate speak!",
                    },
                ]
                input_stream = "Who are you? what can you do"
                input_stream = {"role": "user", "content": input_stream}
                messages.append(input_stream)
            start_time = time.time()
            #output_stream = self.proc_engn_inference(messages, n)
            output_stream = self.proc_engn_inference(messages, 0)
            print(".")
            #print(f"output_stream: {output_stream}")
            print("boot: ", end="")
            ##print
            pre = 0
            for outputs in output_stream:
                output_text = outputs["text"]
                output_text = output_text.strip().split(" ")
                now = len(output_text) - 1
                if now > pre:
                    print(" ".join(output_text[pre:now]), end=" ", flush=True)
                pre = now
            print(" ".join(output_text[pre:]), flush=True)
            ###
            if outputs["finish_reason"] == "len_limit":
                print("\n\n ****The length is more than 8192 and has been withdrawn****")
                break
            generate_token_num = (
                outputs["usage"]["total_tokens"] - outputs["usage"]["prompt_tokens"]
            )
            n = outputs["usage"]["total_tokens"]
            end_time = time.time()
            use_time = end_time - start_time
            print(
                "\n\n****第%d轮对话结束,生成%dtoken,用时%.3f秒,性能为%.2ftoken/秒****"
                % (
                    taps + 1,
                    generate_token_num,
                    use_time,
                    generate_token_num / use_time,
                )
            )
            #messages.append({ "role": "assistant","content": outputs["text"],})
            if ROUNDSleep > 0:
                self.DEBUG1(f"Sleep ...")
                self.ms_sleep(ROUNDSleep)

    def Agile_Card_Main(self):
        self.DEBUGX(f"SYS: Agile_Card_Main")
        data = 0
        while data != CARD_STATUS_READY: 
            data = self.Agile_Status()
            self.DEBUG1(f"CARD_STAT: {data}")
            self.ms_sleep(1000)
        print(f"{data}")

    def Agile_Status(self):
        data = self.PCIe_ReadCtrl(PCIE_ECOS_LLMB_STAT)
        self.DEBUG2(f"AgileCard {self.Card_ID} PCIE_ECOS_LLMB_STAT = {hex(data[0])}")
        return data[0]

    def Agile_Echo(self):
        data = self.Agile_Status()
        hex(data)
        self.DEBUG2(f"AgileCard {self.Card_ID} STAT = {data}")

def Agile_Elaberate():
    N = 0
    AgileCard = []
    if FakePcie == 0:
        print(f"Card {len(AgileCard)}")
        for i in range(Max_Card_Num):
            fileName = f"/dev/chiprise{i}_user"
            if os.path.exists(fileName):
                AgileCard.append(Agile_LLMB(i))
                N += 1
            else:
                break
    else:
        AgileCard.append(Agile_LLMB(0))
    return AgileCard

