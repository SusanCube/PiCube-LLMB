import os
import datetime
from ctypes import *
from config import *

if FakePcie == 0:
    pcie = CDLL(PCIe_DRIVER_FILE)
    
class PCIe_Base(object):

    def __init__(self, cid):
        self.Card_ID = cid
        self.Time = datetime.datetime.now()
        self.ScanTime = datetime.datetime.now()

        self.LogBakDir = f"LogCard"
        self.LogName = f"Card{cid}_Log.log"
        self.ExtName = f"Card{cid}_Ext.log"

        if not os.path.exists(f"{self.LogBakDir}"):
            os.makedirs(f"{self.LogBakDir}")

        if len(sys.argv) > 1 and sys.argv[1] == "agile" and os.path.exists(self.LogName):
            i = 0
            while 1:
                if os.path.exists(f"{self.LogBakDir}/{self.LogName}.{i}"):
                    i = i+1
                else:
                    break
            os.rename(f"{self.LogName}", f"{self.LogBakDir}/{self.LogName}.{i}")

        if len(sys.argv) > 1 and sys.argv[1] == "agile":
            self.Log = open(f"{self.LogName}", "w")
            #self.Log = open(f"/dev/null", "w")
        else:
            self.Log = open(f"{self.ExtName}", "w")
    
    def debugClrs(self):
        self.debugList = []
    
    def debugPuts(self, name, data):
        if type(data) == int:
            hexx = hex(data)
            self.debugList.append([name, data, hexx])
        else:
            self.debugList.append([name, data])
    
    def us_sleep(self, n):
        if FakePcie == 0:
            if 0:
                pcie.us_sleep(n)
            else:
                self.PCIe_WriteCtrl(0x39, [n*3], printEn=0)
                data = [1]
                while data[0] != 0:
                    data = self.PCIe_ReadCtrl(0x39, printEn=0)
    
    def ms_sleep(self, n):
        if FakePcie == 0:
            if 0:
                pcie.ms_sleep(n)
            else:
                self.us_sleep(1000*n)
    
    def test(self):
        pass

    def DEBUGPRINT(self, s, level, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        tt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        tt = tt + f"({self.Card_ID}):{Prefix} "
        if VERBOSE >= level:
            if type(s) == list:
                ss = ""
                for i,s1 in enumerate(s):
                    ss += f"{hex(s1)}  "
                ss = f"{tt}{' '*level*2}" + ss
            else:
                ss = f"{tt}{' '*level*2}{s}"
            print(ss)
            Handle.write(ss + '\n')
            if Handle != self.Log:
                self.Log.write(ss + '\n')
    
    def DEBUG0(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 0, Handle, Prefix)
    
    def DEBUG1(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 1, Handle, Prefix)
    
    def DEBUG2(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 2, Handle, Prefix)
    
    def DEBUG3(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 3, Handle, Prefix)
    
    def DEBUG4(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 4, Handle, Prefix)
    
    def DEBUG5(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 5, Handle, Prefix)
    
    def DEBUG6(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 6, Handle, Prefix)
    
    def DEBUG7(self, s, Handle=0, Prefix=""):
        if Handle == 0:
            Handle = self.Log
        self.DEBUGPRINT(s, 7, Handle, Prefix)

    ####------------------------------------
    
    def tune_analyze(self, data, compData=0x1f):
        [indx, stat] = data
        self.DEBUG4(stat)
        segms = []
        start = -1
        lastt = 0
        for i,s in enumerate(stat):
            if s == compData:
                if start == -1:
                    start = i
                    lastt = lastt + 1
                else:
                    lastt = lastt + 1
            else:
                if start != -1:
                    segms.append([start, lastt])
                    start = -1
                    lastt = 0
        if start != -1:
            segms.append([start, lastt])
        if VERBOSE >= 4:
            print(segms)
        maxt = -1
        maxi = -1
        for i,segm in enumerate(segms):
            if segm[1] > maxt:
                maxt = segm[1]
                maxi = i
        if maxi == -1:
            return []
        good_segm = segms[maxi]
        good_last = good_segm[1]
        good_indx = good_segm[0] + int(good_last/2)
        self.DEBUG4(good_indx)
        self.DEBUG4(f"good_idx {good_indx}")
        good_val = indx[good_indx]
        self.DEBUG4(f"good_val {good_val}({hex(good_val)})")
        return [good_indx, good_val, good_last]

    ####------------------------------------
    
    def pcie_tune_cfig(self, port, tune):
        self.pcie_iowr(0x36, tune)
        if tune == 2:
            self.DEBUG7("\t******** PCIE TUNE TPGM_TXDO_TCLK_ODLY ENABEL!")
        elif tune == 1:
            self.DEBUG7("\t******** PCIE TUNE TPGM_RXDI_DATA_IDLY ENABEL!")
        elif tune == 0:
            self.DEBUG7("\t******** PCIE TUNE TPGM_CHANNEL_DELYA ENABEL!")
        else:
            self.DEBUG7("\t******** PCIE TUNE Configration With ERROR!!!!")
        self.pcie_iowr(0, (port<<16)|0x00000000)

    ####------------------------------------
    
    def pcie_dma_write(self, filename, src_offset, leng, max_splt_size=0x3fffffff):
        if FakePcie == 0:
            pcie.pcie_dma_write(self.Card_ID, filename, src_offset, leng, max_splt_size)
    
    def pcie_dma_read(self, filename, leng, RdStep):
        if FakePcie == 0:
            pcie.pcie_dma_read(self.Card_ID, filename, leng, RdStep)
        else:
            WF = open(filename, 'wb')
            WF.write(b'12345678')
            WF.close()
    
    def pcie_reg_write(self, addr, data, data_len):
        INPUT = c_uint32 * data_len
        c_data = INPUT()
        for i in range(data_len):
            c_data[i] = data[i]
        if 0 and FakePcie == 0:
            for i in range(data_len):
                self.DEBUG7(f"pcie_reg_write {hex(addr+4*i)}({hex(int(addr/4)+i)}) {hex(c_data[i])}")
        if FakePcie == 0:
            pcie.pcie_reg_write(self.Card_ID, addr, c_data, data_len)
    
    def pcie_reg_read(self, addr, data, data_len):
        if FakePcie == 0:
            pcie.pcie_reg_read(self.Card_ID, addr, data, data_len)
    
    ####------------------------------------
    
    def PCIe_WriteData(self, fname, src_offset=0, leng=0, max_splt_size=0x3fffffff):
        filename = bytes(fname, encoding="utf-8")
        self.DEBUG6(f"PCIe_WriteData src_offset={hex(src_offset)} {leng} datas")
        self.pcie_dma_write(filename, src_offset, leng, max_splt_size)
    
    def PCIe_ReadData(self, fname, leng=0, RdStep=0x3fffffff):
        filename = bytes(fname, encoding="utf-8")
        self.pcie_dma_read(filename, leng, RdStep)
    
    def PCIe_WriteCtrl(self, addr=0, data=[], printEn=1):
        addr = addr*4
        data_len = len(data)
        if (len(data) > 1):
            if printEn == 1:
                self.DEBUG6(f"PCIe_WriteCtrl addr={int(addr/4)}({hex(int(addr/4))}) {len(data)} datas:")
            for i in range(data_len):
                if printEn == 1:
                    self.DEBUG6(f"              {i} data={hex(data[i])}")
        else:
            if printEn == 1:
                self.DEBUG6(f"PCIe_WriteCtrl addr={int(addr/4)}({hex(int(addr/4))}) data={hex(data[0])}")
        self.pcie_reg_write(addr, data, data_len)
    
    def PCIe_ReadCtrl(self, addr=0, data_len=1, printEn=0):
        addr = addr*4
        INPUT = c_uint32 * data_len
        data = INPUT()
        if printEn == 1:
            self.DEBUG7(f"PCIe_ReadCtrl {int(addr/4)}({hex(int(addr/4))}) =>")
        self.pcie_reg_read(addr, data, data_len)
        if printEn == 1:
            for i in range(len(data)):
                self.DEBUG7(f"                          => data [ {hex(i)[2:]} ] = {hex(data[i])}")
        return data
    
    def PCIe_ReadCtrl_Util(self, PCIe_REGS, PCIe_Val, PCIe_Mask=0xffffffff, HardAcks=0):
        STAT = 0
        First = 1
        i = 0
        j = 1
        while First == 1 or STAT != PCIe_Val:
            First = 0
            STAT = self.PCIe_ReadCtrl(PCIe_REGS, 1, 0)
            STAT0 = STAT[0]
            STAT = (STAT0 & PCIe_Mask)
            #self.DEBUG7(f"PCIe_ReadCtrl_Util {PCIe_REGS}({hex(PCIe_REGS)}) => {hex(STAT0)} & {hex(PCIe_Mask)} ==> {hex(STAT)} expect({hex(PCIe_Val)})")
            if FakePcie == 1:
                STAT = PCIe_Val
            #self.DEBUG6(f"                              => {hex(STAT)} expect({hex(PCIe_Val)})")
            if HardAcks == 1:
                if STAT != PCIe_Val:
                        #self.DEBUG7(f"wait 1 us")
                        self.us_sleep(1)
            else:
                if STAT != PCIe_Val and i == 2:
                    self.DEBUG7(f"wait {j} us")
                    self.us_sleep(j)
                    if j < 4294967295:
                        j = j * 2
                    else:
                        while 1:
                            pass
                    i = 0
                else:
                    i = i + 1
        self.DEBUG6(f"")
    
    def PCIe_WriteCtrlThenReadCtrlUtil(self, addr=0, data=[], addrToRead=0, waitForValue=0, waitForMask=0xffffffff):
        self.PCIe_WriteCtrl(addr, data)
        self.PCIe_ReadCtrl_Util(addrToRead, waitForValue, waitForMask)
    
    ###--------------------------------------
    
    def pcie_case(self, addr, mask):
        self.DEBUG7(f"pcie_case {hex(addr)}(hex(int(addr/4))) {hex(mask)}")
        self.PCIe_ReadCtrl_Util(addr, mask, mask)

    def pcie_iowr(self, addr, data):
        self.DEBUG7(f"pcie_iowr {hex(addr)}(hex(int(addr/4))) {hex(data)}")
        self.PCIe_WriteCtrl(0, [0])
        self.PCIe_WriteCtrl(addr, [data])
        self.PCIe_WriteCtrl(0, [0])

    def pcie_cfig_nnex(self, aux1=0, aux2=0):
        self.PCIe_WriteCtrl(DEST_PORT_ENAB + 13, [aux1, aux2, 0x15000053])

    def pcie_cfig_nnex_cfig(self):
        self.PCIe_WriteCtrl(DEST_PORT_ENAB, [APAE, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x15000053])

    def pcie_cfig_cmnd(self, port_enab, tpgs, tpes, edge, sadr=0, madr=0, rows_numb=0, cols_numb=0, rows_pack=0, pack_page=0, dlnk_pack=0, dlnk_mult=0, aux0=0, aux1=0, aux2=0, aux3=0):
        cmds = [port_enab, tpgs, tpes, edge, sadr, madr, rows_numb, cols_numb, rows_pack, pack_page, dlnk_pack, dlnk_mult, aux0, aux1, aux2, aux3]
        self.PCIe_WriteCtrl(DEST_PORT_ENAB, cmds)
    
    def pcie_rstn_tpgs(self):
        self.DEBUG2(f"pcie_rstn_tpgs")
        self.PCIe_WriteCtrl(TPGM_GSET_CTRL, [LLMB_RSTN_CMND])
        self.PCIe_ReadCtrl_Util(TPGM_GSET_CTRL, 0xf)
    
    def pcie_issu_cmnd(self, cmnd, HardAcks=0):
        self.DEBUG7(f"pcie_issu_cmnd {hex(cmnd)}")
        self.PCIe_ReadCtrl_Util(TPGM_GSET_CTRL, 0xf)
        if 0:
            pass
        else:
            self.DEBUG6(f"write TPGM_CMND_CTRL")
            self.PCIe_WriteCtrl(TPGM_CMND_CTRL, [cmnd])
            if cmnd == LLMB_ICFG_CMND:   ## 0x11
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ICFG_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ICFG_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_OCFG_CMND: ## 0x12
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_OCFG_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OCFG_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_NNEX_CMND: ## 0x13
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_NNEX_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_NNEX_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_IVCT_CMND: ## 0x21
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_IVCT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_IVCT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_OVCT_CMND: ## 0x22
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_OVCT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OVCT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_IMTX_CMND: ## 0x23
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_IMTX_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_IMTX_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_OMTX_CMND: ## 0x24
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_OMTX_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OMTX_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_RIVT_CMND: ## 0x31
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_RIVT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RIVT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_ROVT_CMND: ## 0x32
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ROVT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROVT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_RIMT_CMND: ## 0x33
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_RIMT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RIMT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_ROMT_CMND: ## 0x34
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ROMT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROMT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_RISV_CMND: ## 0x41
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_RISV_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RISV_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_ROSV_CMND: ## 0x42
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ROSV_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROSV_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_RISM_CMND: ## 0x43 ## 0x41
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_RISM_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RISM_CMND_rdy, LLMB_RISM_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_ROSM_CMND: ## 0x44 ## 0x42
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ROSM_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROSM_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_ASET_CMND: ## 0x51
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_ASET_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ASET_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_DNLD_CMND: ## 0x52
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_DNLD_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_DNLD_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_BOOT_CMND: ## 0x53
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_BOOT_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_BOOT_CMND_rdy, HardAcks=HardAcks)
            elif cmnd == LLMB_TRIM_CMND: ## 0x88
                self.DEBUG6("\t\t\t\t\t\t******** PCIE_ISSU_CMND::\t LLMB_TRIM_CMND")
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_TRIM_CMND_rdy, HardAcks=HardAcks)

            #self.PCIe_WriteCtrl(TPGM_CMND_CTRL, [0])
            self.us_sleep(2)
    
    def pcie_down_load(self, code):
        leng = len(code)
        bls = [hex(it) for it in code]
        i = 0
        self.DEBUG4(f"\t\t\t\t\t\t********TPGS CodeRam Download {leng} PACKAGES")
        while (i<leng):
            self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
            self.PCIe_WriteCtrl(META_ROWS_NUMB, code[i:i+8])
            self.pcie_issu_cmnd(LLMB_DNLD_CMND)
            i = i + 8
    
    def pcie_2805_load(self, code):
        leng = len(code)
        bls = [hex(it) for it in code]
        i = 0
        self.DEBUG4(f"\t\t\t\t\t\t********TPGS CodeRam Download {leng} PACKAGES")
        if MODE in [MODE_Release_20250115_PCB, MODE_Release_20250115_FULL]: ## Use 202411291738, Old Word Order
            self.DEBUG4(f"MODE {MODE} in {[MODE_Release_20250115_PCB, MODE_Release_20250115_FULL]}")
            while (i<leng-8):
                self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
                self.PCIe_WriteCtrl(EDGE_DEST_MARK, code[i+0:i+2])
                self.PCIe_WriteCtrl(DLNK_BULK_PACK, code[i+2:i+4])
                self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, code[i+4:i+8])
                self.pcie_issu_cmnd(LLMB_DNLD_CMND)
                i = i + 8
        else:
            self.DEBUG4(f"MODE {MODE} not in {[MODE_Release_20250115_PCB, MODE_Release_20250115_FULL]}")
            while (i<leng-8):
                self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
                self.PCIe_WriteCtrl(EDGE_DEST_MARK, code[i+0:i+1])
                self.PCIe_WriteCtrl(SLAV_DDRS_BASE, code[i+1:i+2])
                self.PCIe_WriteCtrl(META_ROWS_NUMB, code[i+2:i+4])
                self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, code[i+4:i+8])
                self.pcie_issu_cmnd(LLMB_DNLD_CMND)
                i = i + 8
        self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
        self.PCIe_WriteCtrl(EDGE_DEST_MARK, code[i+0:i+2])
        self.PCIe_WriteCtrl(DLNK_BULK_PACK, code[i+2:i+4])
        self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, code[i+4:i+8])
        self.pcie_issu_cmnd(LLMB_DNLD_CMND)
    
    ##  addr 32byte address
    def pcie_wdma_ddrs(self, fname, addr, rows, cols, src_offset_spot=0, max_splt_size=0x3fffffff):
        rows = int(rows)
        cols = int(cols)
        if cols == 0:
            return
        self.DEBUG4(f"PCIE_AXIS_WRIT_MEMO@ADDR:{hex(addr)}, ROWS:{hex(rows)}, COLS:{hex(cols)} src_offset_spot:{hex(src_offset_spot)}")
        self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
        #self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [rows])
        self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [1])
        self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
        self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_wdma])
        ## Axi-Stream, No addr signal
        if 1 and max_splt_size == 0x3fffffff:
            max_splt_size = 0x00100000
        self.PCIe_WriteData(fname, src_offset_spot*2, rows*cols*2, max_splt_size)
        #self.PCIe_WriteData(fname, src_offset_spot*2, 0)
        self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_wdma_rdy, PCIE_XDMA_CMND_wdma_rdy)
    
    ##  addr 32byte address
    def pcie_rdma_ddrs(self, fname, addr, rows, cols, RdStep=0x3fffffff):
        rows = int(rows)
        cols = int(cols)
        if cols == 0:
            return
        #input("trig pcie")
        self.DEBUG4(f"PCIE_AXIS_READ_MEMO@ADDR:{hex(addr)}, ROWS:{hex(rows)}, COLS:{hex(cols)}")
        self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
        self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [rows])
        self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [cols])
        self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_rdma])
        ## Axi-Stream, No addr signal
        if 0 and RdStep == 0x3fffffff:
            RdStep = 0x00010000  ## this cause error, but why?
        self.PCIe_ReadData(fname, rows*cols*2, RdStep)
        self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_rdma_rdy, PCIE_XDMA_CMND_rdma_rdy)

