import os
import sys
from config import *
from pcie_base_task import *
from pcie_core_func import *
from base_core_util import *
import numpy as np


class ENGN_CORE(PCIe_Base):

    def __init__(self):
        pass

    def mast_engn_writ_tpgm(self, FILE, MASTER, length=-1):
        if length == -1:
            size = os.path.getsize(FILE)
        else:
            size = length
        size_spot = size // 2
        rows_tile = size_spot // LINE_COLS
        cols_left = size_spot - rows_tile * LINE_COLS
        self.DEBUG5(f"mast_engn_writ_tpgm {FILE} {size_spot} = {rows_tile} * {LINE_COLS} + {cols_left}")
        if rows_tile > 0:
            self.pcie_wdma_ddrs(FILE, MASTER, rows_tile, LINE_COLS)
        offset = 0
        if cols_left > 0:
            spot_offset = rows_tile * LINE_COLS
            offset = int(spot_offset / 16)
            self.pcie_wdma_ddrs(FILE, MASTER + offset, 1, cols_left, spot_offset)
        return [MASTER, rows_tile, offset, cols_left, size_spot]
        #return {"master":MASTER, "rows":rows_tile, "offset":offset, "cols_left":cols_left, "size_spot":size_spot}

    def proc_tpgm_ovct_tpes(self, slave_offset, pcie_writ_info, OP, DVP=DVPD, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        [master, rows, offset, cols_left, size_spot] = pcie_writ_info
        if rows > 0:
            self.DEBUG4(f"slave_offset, {hex(slave_offset)}")
            self.tpgm_ovct_tpes(slave_offset, master, rows, LINE_COLS, rows, LINE_COLS, OP, DVP, portMsk)
        if cols_left > 0:
            self.DEBUG4(f"slave_offset, {hex(slave_offset + offset//2)}")
            self.tpgm_ovct_tpes(slave_offset + offset//2, master + offset, 1, cols_left, 1, cols_left, OP, DVP, portMsk)

    def proc_engn_writ_code(self, length=-1):
        pcie_writ_info = self.mast_engn_writ_tpgm(CodeImg, MAST_CODE_BASE, length)
        self.DEBUG4(f"proc_engn_writ_code {CodeImg} {pcie_writ_info}")
        self.proc_tpgm_ovct_tpes(0, pcie_writ_info, WRIT_NNEX_GNPU_CODE, DVP=DVP0)
        self.proc_chck_data(f"{CodeImg}", SLAV_CODE_BASE, port=0, edge=0, attn=0, check=1, stop=1, hexMode=8, dataType="code")
        return pcie_writ_info

    def writ_to_read_info(self, pcie_writ_info):
        [MASTER, rows_tile, offset, cols_left, size_spot] = pcie_writ_info
        total_cols = rows_tile * LINE_COLS + cols_left
        splt_rows = total_cols // READ_COLS
        actl_cols = splt_rows * READ_COLS
        cols_left = total_cols - actl_cols
        offset = actl_cols // 16
        return [MASTER, splt_rows, offset, cols_left, size_spot]

    def proc_tpgm_ivct_tpes(self, slave_offset, pcie_read_info, OP, GSML, portMsk, cols=READ_COLS):
        [master, rows, offset, cols_left, size_spot] = pcie_read_info
        if rows > 0:
            self.tpgm_ivct_tpes(slave_offset, master, rows, cols, rows, cols, OP, GSML, portMsk)
        if cols_left > 0:
            self.tpgm_ivct_tpes(slave_offset + offset//2, master + offset, 1, cols_left, 1, cols_left, OP, GSML, portMsk)

    def proc_engn_writ_wght(self, loop, p, e, g):
        n = 2 * (EDGE_NUM * p + e) + g
        if g==0:
            DVP=DVP0
            GSM=GSME
        else:
            DVP=DVP1
            GSM=GSMO
        FILE = f"{WGHT_PATH}/loop/{loop}/weight{n}.img"
        self.DEBUG4(f"proc_engn_writ_wght loop={loop} p={p} e={e} DVP={g}")
        pcie_writ_info = self.mast_engn_writ_tpgm(FILE, MAST_WGHT_BASE)
        self.DEBUG4(f"proc_engn_writ_wght {FILE} {pcie_writ_info}")
        portMsk = ((2**p) << 16) | (2**e)
        self.proc_tpgm_ovct_tpes(SLAV_WGHT_BASE + loop * WGHT_SIZE, pcie_writ_info, WRIT_NNEX_DATA_NULL, DVP, portMsk)

    def proc_engn_wght_apae(self, head=0):
        self.DEBUG3(f"proc_engn_wght_apae")
        for loop in range(MLP_ROUND):
            self.DEBUG3(f"proc_engn_wght_apae LOOP={loop} Even")
            for p in PP:
                for e in EE:
                    self.proc_engn_writ_wght(loop, p, e, 0)

            self.DEBUG3(f"proc_engn_wght_apae LOOP={loop} Odd")
            for p in PP:
                for e in EE:
                    self.proc_engn_writ_wght(loop, p, e, 1)

    def proc_engn_writ_wght_head(self, p, e, g):
        n = 2 * (EDGE_NUM * p + e) + g
        if g==0:
            DVP=DVP0
            GSM=GSME
        else:
            DVP=DVP1
            GSM=GSMO
        FILE = f"{WGHT_PATH}/head/weight{n}.img"
        self.DEBUG4(f"proc_engn_writ_wght_head p={p} e={e} DVP={g}")
        pcie_writ_info = self.mast_engn_writ_tpgm(FILE, MAST_WGHT_BASE)
        self.DEBUG4(f"proc_engn_writ_wght_wght {FILE} {pcie_writ_info}")
        portMsk = ((2**p) << 16) | (2**e)
        self.proc_tpgm_ovct_tpes(SLAV_HEAD_BASE, pcie_writ_info, WRIT_NNEX_DATA_NULL, DVP, portMsk)

    def proc_engn_wght_apae_head(self, head=0):
        for p in PP:
            for e in EE:
                self.proc_engn_writ_wght_head(p, e, 0)
        for p in PP:
            for e in EE:
                self.proc_engn_writ_wght_head(p, e, 1)

    def proc_strs_to_tokn(self, prompt):
        input_ids = tokenizer.apply_chat_template(
                prompt,
                tokenize=True,
                add_generation_prompt=True
        )
        return input_ids

    def proc_tokn_to_vect(self, input_ids):
        self.DEBUG4(f"proc_tokn_to_vect {input_ids}")
        n_ids = len(input_ids)
        vec = []
        if n_ids <= n_Voc:
            for ids in input_ids:
                data = Voc[ids]
                vec.append(data)
        res = np.array(vec)
        self.DEBUG4(f"vect {res}")
        binWF = open(NNEX_WRIT_FILE, 'wb')
        binWF.write(res)
        binWF.close()
        self.DEBUG5(f"toks done")
        return n_ids

    def proc_chck_data(self, FILE, tile_addr, port, edge, attn, check=0, stop=0, hexMode=2, dataType="data", tags=""):
        portMsk = ((2**port) << 16) | (2**edge)
        if attn == 0:
            GSM = GSME
        else:
            GSM = GSMO
        if check == 1:
            readBack = "readBack"
            pcie_writ_info = self.mast_engn_writ_tpgm(FILE, 0x800)
            pcie_read_info = self.writ_to_read_info(pcie_writ_info)
            pcie_read_info[0] += 0x100
            self.proc_tpgm_ivct_tpes(tile_addr, pcie_read_info, READ_NNEX_DATA_NULL, GSM, portMsk)
            self.pcie_rdma_ddrs(readBack, pcie_read_info[0], 1, pcie_read_info[4])
            if hexMode == 2:
                cmd1 = f"python3 ../bin/img2hex.py {FILE} {FILE}.hex"
                cmd2 = f"python3 ../bin/img2hex.py {readBack} {self.LogBakDir}/{readBack}_{dataType}.hex"
                cmd3 = f"diff {FILE}.hex {self.LogBakDir}/{readBack}_{dataType}.hex >> error"
            else:
                cmd1 = f"python3 ../bin/img2hex.py {FILE} {FILE}.hex{hexMode} {hexMode}"
                cmd2 = f"python3 ../bin/img2hex.py {readBack} {self.LogBakDir}/{readBack}_{dataType}.hex{hexMode} {hexMode}"
                cmd3 = f"diff {FILE}.hex{hexMode} {self.LogBakDir}/{readBack}_{dataType}.hex{hexMode} >> error"
            cmd4 = f"cp {readBack} {self.LogBakDir}/{readBack}_{dataType}.img"
            self.DEBUG4(cmd1)
            self.DEBUG4(cmd2)
            self.DEBUG4(cmd3)
            self.DEBUG4(cmd4)
            os.system(cmd1)
            os.system(cmd2)
            df = os.system(cmd3)
            os.system(cmd4)
            self.DEBUG4(f"{tags} {cmd3} => {df}")
            if hexMode == 2:
                self.DEBUG4(f"vimdiff {FILE}.hex  {self.LogBakDir}/{readBack}_{dataType}.hex")
            else:
                self.DEBUG4(f"vimdiff {FILE}.hex{hexMode} {self.LogBakDir}/{readBack}_{dataType}.hex{hexMode}")
            if stop == 1 and df > 0:
                input(f"")

    def proc_engn_writ_data(self, LineStart, LineCount, Boost):
        self.DEBUG4(f"proc_engn_writ_data LineStart={LineStart} LineCount={LineCount} Boost={Boost}")

        portMLPLen = ATTN_NUM * MLPLen
        portFINLen = ATTN_NUM * FINLen
        portEMBLen = ATTN_NUM * EMBLen
        fullMLPLen = TOTAL_GNPU * MLPLen
        fullFINLen = TOTAL_GNPU * FINLen
        fullEMBLen = TOTAL_GNPU * EMBLen

        if 1: ## Boost:
            self.DEBUG4(f"Write DATA to DDRC tpgm_omtx_tpes")
            pcie_writ_info = self.mast_engn_writ_tpgm(f"{NNEX_WRIT_FILE}", MAST_DINP_BASE)

        for n in range(MLP_ROUND):
            self.DEBUG4(f"Loop {n} of {MLP_ROUND}")

            ## NNEX RMSNorm
            self.tpgm_omtx_tpes(SV_SHARE5_BASE, MAST_DINP_BASE, LineCount, fullEMBLen,                     WRIT_NNEX_DATA_NULL, DVPD, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} omtx")
            self.pcie_proc_nnex(LineStart, LineCount, n, NNEX_RMSNorm)
            self.DEBUGX(f"Boost={Boost} loop={n} RMSNorm")
            if STEP1Sleep > 0:
                self.ms_sleep(STEP1Sleep)
            self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSME, APAE)
            self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSMO, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} rimt")
            self.tpgm_rism_tpgs(MAST_DATA_BASE, MAST_DATA_BASE, LineCount, fullEMBLen, LineCount, EMBLen,                             AP  )
            self.DEBUGX(f"Boost={Boost} loop={n} rism")

            ## NNEX O GEMM
            self.tpgm_omtx_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, fullEMBLen,                     WRIT_NNEX_DATA_NULL, DVPD, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} omtx")
            self.pcie_proc_nnex(LineStart, LineCount, n, NNEX_OGemm)
            self.DEBUGX(f"Boost={Boost} loop={n} OGemm")
            if STEP2Sleep > 0:
                self.ms_sleep(STEP2Sleep)
            self.tpgm_rimt_tpes(SV_SHARE4_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSME, APAE)
            self.tpgm_rimt_tpes(SV_SHARE4_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSMO, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} rimt")
            self.tpgm_rism_tpgs(MAST_DATA_BASE, MAST_DATA_BASE, LineCount, fullEMBLen, LineCount, EMBLen,                             AP  )
            self.DEBUGX(f"Boost={Boost} loop={n} rism")

            ## NNEX RMSNormMid
            self.tpgm_omtx_tpes(SV_SHARE1_BASE, MAST_DATA_BASE, LineCount, fullEMBLen,                     WRIT_NNEX_DATA_NULL, DVPD, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} omtx")
            self.pcie_proc_nnex(LineStart, LineCount, n, NNEX_RMSNormMid)
            self.DEBUGX(f"Boost={Boost} loop={n} RMSMid")
            if STEP3Sleep > 0:
                self.ms_sleep(STEP3Sleep)
            self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portMLPLen, LineCount, MLPLen,  READ_NNEX_DATA_NULL, GSME, APAE)
            self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portMLPLen, LineCount, MLPLen,  READ_NNEX_DATA_NULL, GSMO, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} rimt")
            self.tpgm_rism_tpgs(MAST_DATA_BASE, MAST_DATA_BASE, LineCount, fullMLPLen, LineCount, MLPLen,                             AP  )
            self.DEBUGX(f"Boost={Boost} loop={n} rism")

            ## NNEX DOWN
            self.tpgm_omtx_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, fullMLPLen,                     WRIT_NNEX_DATA_NULL, DVPD, APAE)
            self.DEBUGX(f"Boost={Boost} loop={n} omtx")
            self.pcie_proc_nnex(LineStart, LineCount, n, NNEX_LongGemm)
            self.DEBUGX(f"Boost={Boost} loop={n} Down")
            if STEP4Sleep > 0:
                self.ms_sleep(STEP4Sleep)
            if n == MLP_ROUND - 1:
                offset = 128 * (LineCount - 1) // 32
                self.tpgm_rimt_tpes(SV_SHARE2_BASE + offset, MAST_DATA_BASE, 1, portEMBLen, 1, EMBLen,  READ_NNEX_DATA_NULL, GSME, APAE)
                self.tpgm_rimt_tpes(SV_SHARE2_BASE + offset, MAST_DATA_BASE, 1, portEMBLen, 1, EMBLen,  READ_NNEX_DATA_NULL, GSMO, APAE)
                self.DEBUGX(f"Boost={Boost} loop={n} rimt")
                self.tpgm_rism_tpgs(MAST_DATA_BASE,          MAST_DATA_BASE, 1, fullEMBLen, 1, EMBLen,                             AP  )
                self.DEBUGX(f"Boost={Boost} loop={n} rism")
            else:
                self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSME, APAE)
                self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DATA_BASE, LineCount, portEMBLen, LineCount, EMBLen,  READ_NNEX_DATA_NULL, GSMO, APAE)
                self.DEBUGX(f"Boost={Boost} loop={n} rimt")
                self.tpgm_rism_tpgs(MAST_DATA_BASE, MAST_DATA_BASE, LineCount, fullEMBLen, LineCount, EMBLen,                             AP  )
                self.DEBUGX(f"Boost={Boost} loop={n} rism")

        ## NNEX FINAL
        self.tpgm_omtx_tpes(SV_SHARE5_BASE, MAST_DINP_BASE,         1, fullEMBLen,                    WRIT_NNEX_DATA_NULL, DVPD, APAE)
        self.pcie_proc_nnex(LineStart,         1, 0, NNEX_RMSNormFinal)
        self.DEBUGY(f"Token")
        if FINALSleep > 0:
            self.ms_sleep(FINALSleep)
        #self.check_gnpu_status(pause=1)
        self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DOUT_BASE,         1, portFINLen,         1, FINLen, READ_NNEX_DATA_NULL, GSME, APAE)
        self.tpgm_rimt_tpes(SV_SHARE2_BASE, MAST_DOUT_BASE,         1, portFINLen,         1, FINLen, READ_NNEX_DATA_NULL, GSMO, APAE)
        self.tpgm_rism_tpgs(MAST_DOUT_BASE, MAST_DOUT_BASE,         1, fullFINLen,         1, FINLen,                            AP  )
        #self.DEBUG4(f"READ DATA FROM DDRC pcie_rdma_ddrs {NNEX_READ_FILE} {MAST_DOUT_BASE} 1 {2016*64}")
        self.pcie_rdma_ddrs(NNEX_READ_FILE, MAST_DOUT_BASE, 1, 1*2016*64)
        #os.system(f"cp {NNEX_READ_FILE} LogCard/readBack_B{Boost}_S{LineStart}C{LineCount}_finalLine.img")
        #os.system(f"python3 ../bin/img2hex.py LogCard/readBack_B{Boost}_S{LineStart}C{LineCount}_finalLine.img LogCard/readBack_B{Boost}_S{LineStart}C{LineCount}_finalLine.hex")

    def proc_vect_to_tokn(self):
        binRF = open(NNEX_READ_FILE, 'rb')
        rData = binRF.read()
        tids = np.frombuffer(rData, dtype=np.int16).reshape(129024)
        maxIndx = 0
        maxValu = -999
        i = 0
        for d in tids:
            if d > maxValu:
                maxValu = d
                maxIndx = i
            i = i + 1
        token = maxIndx
        #print(f"maxDt {maxValu} token {token}")
        return token

    def proc_tokn_to_strs(self, toks):
        txt = tokenizer.decode(toks, skip_special_tokens=True, spaces_between_special_tokens=False,)
        return txt

    def proc_engn_inference(self, prompt, LineStart=0):
        self.DEBUGX(f"proc_engn_inference")
        input_ids = self.proc_strs_to_tokn(prompt)
        input_echo_len = len(input_ids)
        boost = 1
        toks = []
        self.T0Init()
        for i in range(MAXTOKENLEN - input_echo_len):
            rows = self.proc_tokn_to_vect(input_ids)
            self.proc_engn_writ_data(LineStart, LineCount=rows, Boost=boost)
            output_token = self.proc_vect_to_tokn()
            toks.append(output_token)
            output_txt = self.proc_tokn_to_strs(toks)
            #self.DEBUG1(f"TK {output_token} TXT {output_txt}")
            if output_token not in END_TOKEN:
                input_ids = [output_token]
                LineStart += rows
                boost= 0
                yield {
                    "text": output_txt,
                    "usage": {
                        "prompt_tokens": input_echo_len,
                        "completion_tokens": i,
                        "total_tokens": input_echo_len + i + 1,
                    },
                    "finish_reason": None,
                }
            else:
                stop = 1
                break
        if stop == 1:
            finish_reason = "stop"
        elif i == (8192 - input_echo_len -1):
            finish_reason = "len_limit"
        else:
            finish_reason = None
        yield {
            "text": output_txt,
            "usage": {
                "prompt_tokens": input_echo_len,
                "completion_tokens": i,
                "total_tokens": input_echo_len + i,
            },
            "finish_reason": finish_reason,
        }
        
    def check_gnpu_input(self, pause=0):
        self.cube_ddrc_partsel(ddr=0, part=0)
        for i in range(8):
            data = self.epdc_out_or_ddr(indx=i, gnpu=0, epdc=0, ddrAddr=0x80001800)
            self.DEBUG4(f"input dat{i} = {hex_str(data)}")
            if pause == 1:
                input(f"")

    def check_gnpu_output(self, pause=0):
        self.cube_ddrc_partsel(ddr=0, part=0)
        for t in range(8):
            i = t + 8
            data = self.epdc_out_or_ddr(indx=i, gnpu=0, epdc=0, ddrAddr=0x80002000)
            self.DEBUG4(f"output dat{i}(out{t}) = {hex_str(data)}")
            if pause == 1:
                input(f"")

    def check_gnpu_status(self, pause=0):
        H_BASE = LAMA_RISV_PARA[7]['PARA']
        H_GEMM = LAMA_RISV_PARA[20]['PARA']
        cpuAddr = self.ddrAddr2cpuAddrSel((H_BASE+H_GEMM)*64, ddr=0)
        wght = self.pcie_icfg_cube(cpuAddr, single=0)
        if pause == 1:
            input(f"wght = {hex_str(wght)}")

        SHARE3 = LAMA_RISV_PARA[2]['PARA']
        cpuAddr = self.ddrAddr2cpuAddrSel(SHARE3*64, ddr=0)
        data = self.pcie_icfg_cube(cpuAddr, single=0)
        if pause == 1:
            input(f"data = {hex_str(data)}")

        SHARE2 = LAMA_RISV_PARA[1]['PARA']
        cpuAddr = self.ddrAddr2cpuAddrSel(SHARE2*64, ddr=0)
        dout = self.pcie_icfg_cube(cpuAddr, single=0)
        if pause == 1:
            input(f"dout = {hex_str(dout)}")
        self.check_gnpu_output(pause)

