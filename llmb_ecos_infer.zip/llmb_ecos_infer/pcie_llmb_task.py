import time
from config import *
from pcie_base_task import *
#from pcie_link_util import *
from base_core_util import *

class PCIe_LLMB(PCIe_Base):

    def __init__(self, cid):
        PCIe_Base.__init__(self, cid)

    ###--------------------------------------
    
    def pcie_read_resp(self, single=0):
        res = []
        if single == 1:
            port = []
            data = self.PCIe_ReadCtrl(0x10)
            port.append(data[0])
            res.append(port)
        else:
            for p in PP:
                port = []
                for e in EE:
                    data = self.PCIe_ReadCtrl(0x10 + p*8 + e)
                    self.DEBUG6(f"port {p} edge {e} ACKS = {hex(data[0])}")
                    self.DEBUG6(f"")
                    port.append(data[0])
                res.append(port)
        return res

    ##----------------------------------------
    
    def tpgm_icfg_ecos(self, port_enab):
        self.pcie_cfig_cmnd(port_enab,  4, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND)
    
    def tpgm_ocfg_ecos(self, port_enab, aux0=0, aux1=0, aux2=0, aux3=0):
        self.pcie_cfig_cmnd(port_enab, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    
    ###--------------------------------------
    
    def tpem_ocfg_tpes(self, addr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"tpem_ocfg_tpes")
        real_addr = TPES_REGS_OFFSET + addr*4
        self.pcie_cfig_cmnd(portMsk, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, real_addr, data, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    
    def tpem_icfg_tpes(self, addr, portMsk=-1, resp=1, single=0):
        if portMsk == -1:
            portMsk = APAE
        real_addr = TPES_REGS_OFFSET + addr*4
        self.DEBUG6(f"tpem_icfg_tpes {hex(real_addr)}")
        self.pcie_cfig_cmnd(portMsk, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, real_addr, 0, 0, 0);
        self.pcie_issu_cmnd(LLMB_ICFG_CMND)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res
    
    ###--------------------------------------
    
    def pcie_ocfg_nnex(self, data, op):
        self.DEBUG6(f"pcie_ocfg_nnex, write {hex(data)} to icube op {hex(op)}")
        self.pcie_cfig_nnex(data, op)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, HardAcks=1)
   
    def pcie_cube_cmnd(self, LLMB_CMND, arg0=0, arg1=0, arg2=0, arg3=0, arg4=0, arg5=0, arg6=0, arg7=0, portMsk=-1, WaithAcks=0):
        self.pcie_cfig_cmnd(portMsk, 0, 0, arg0, 0, arg1, 0, 0, arg2, arg3, 0, 0, arg4, arg5, arg6, arg7)
        self.pcie_issu_cmnd(LLMB_CMND, WaithAcks)

    def pcie_ocfg_cube(self, addr, data, op=0, portMsk=-1, WaithAcks=0):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"pcie_ocfg_cube, write {hex(data)} to icube addr {hex(addr)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, addr, data, op, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, WaithAcks)
   
    def pcie_ocfg_cksm(self, cksum_addr, cksum_length, cksum_code, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"pcie_ocfg_cksm, cksum_addr={hex(cksum_addr)} cksum_length={hex(cksum_length)} cksum_code={hex(cksum_code)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, cksum_addr, 0, 0, 0, 0, 0, 0, cksum_length, cksum_code, OP_CODE_CKSUM, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, 0)
   
    def pcie_icfg_cube(self, addr, data=0, op=0, portMsk=-1, WaithAcks=0, resp=1, single=0):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"pcie_icfg_cube, read a byte data from icube addr {hex(addr)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, addr, data, op, 0x15000054)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND, WaithAcks)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res

    def cube_ddrc_partsel(self, ddr, part):
        ddrsel = 0
        if ddr == 1:
            ddrsel = 0x00008000
        if part == 1:
            ddrsel = 0x00001000
        self.pcie_ocfg_cube(0x5008, ddrsel)

    ##====================
    
    def tpes_enab_rstn(self):
        self.tpem_ocfg_tpes(TPES_RSTN_CTRL, TPES_RSTN_CTRL_rstn)

    def tpes_enab_ispm(self):
        #self.tpem_ocfg_tpes(TPES_UART_CTRL, 0x3)
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0x00)

        self.tpem_icfg_tpes(TPES_SYSC_STAT)
        #input(f"confirm QUIZ")
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0xff)
        #self.tpem_ocfg_tpes(TPES_ISPM_CTRL, TPES_ISPM_CTRL_enab)
        self.tpem_ocfg_tpes(TPES_RSTN_CTRL, TPES_RSTN_CTRL_rstn)
        self.ms_sleep(1000)
        self.tpem_ocfg_tpes(TPES_RSTN_CTRL, TPES_RSTN_CTRL_free)
        self.ms_sleep(1000)
        self.tpem_icfg_tpes(TPES_SYSC_STAT)
        self.tpem_icfg_tpes(TPES_BAUD_RATE)
        self.tpem_icfg_tpes(TPES_UART_CTRL)

        self.ms_sleep(100)
        #self.tpem_ocfg_tpes(TPES_SYSC_STAT, TPES_SYSC_STAT_w_ok|TPES_SYSC_STAT_g_ok)
    
    ##====================
    
    def gnpu_nnex_func(self, aux0, aux1, aux2, aux3, portMsk=-1, func=LLMB_OCFG_CMND):
        if portMsk == -1:
            portMsk = APAE
        ##  python                   1  2  3  4  5  6  7  8  9  a  b    c     d     e     f
        ##   edge                         w0    w1       w2 w3          w4    w5    w6    w7
        self.pcie_cfig_cmnd(portMsk, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(func, 0)


    def gnpu_natv_func(self, aux0, aux1, aux2, aux3, portMsk=-1, resp=0, func=LLMB_OCFG_CMND, single=0):
        if portMsk == -1:
            portMsk = APAE
        ##  python                   1  2  3  4  5  6  7  8  9  a  b    c     d     e     f
        ##   edge                         w0    w1       w2 w3          w4    w5    w6    w7
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(func, 0)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res

    ## 0x15000000
    def gnpu_natv_freq(self, freq, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG4(f"gnpu_natv_freq, freq={freq}")
        self.gnpu_natv_func(freq, GNPU_ENAB_BOTH, 0, 0x15000000)

    ## 0x15000001
    def gnpu_natv_dnld(self, Code_Size, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"gnpu_natv_dnld")
        self.gnpu_natv_func(1, GNPU_ENAB_BOTH, Code_Size, 0x15000001)
   
    ## 0x15000002
    def gnpu_natv_boot(self, Mode=RESET_RSET_BOOT, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"gnpu_natv_boot")
        self.gnpu_natv_func(0, GNPU_ENAB_BOTH, Mode, 0x15000002)
   
    ## 0x15000003
    def gnpu_risv_freq(self, freq, ECLK=0, ICLK=3, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG4(f"gnpu_risv_freq, freq={freq} ECLK={ECLK} ICLK={ICLK}")
        self.gnpu_natv_func(freq, ECLK, ICLK, 0x15000003)

    ## 0x15000053 1 cksum

    ## 0x15000053 2 null

    ## 0x15000053 3
    def gnpu_ocfg_scan(self, G=1):
        self.pcie_ocfg_nnex(G, op=3)

    ## 0x15000053 4
    def gnpu_ocfg_dnld(self, N=0, WaithAcks=0):
        self.pcie_ocfg_cube(0, N, op=4, WaithAcks=WaithAcks)

    ## 0x15000053 5
    def gnpu_ocfg_gemm(self, N=1250):
        self.pcie_ocfg_nnex(N, op=5)
    def gnpu_ocfg_test(self, N=1250):
        self.DEBUG6(f"pcie_ocfg_test, {N}")
        self.pcie_cfig_cmnd(APAE, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, N, 5, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, HardAcks=0)

    ## 0x15000053 6
    def gnpu_ocfg_stop(self, WaithAcks=0):
        self.pcie_ocfg_cube(0, 0, op=6, WaithAcks=WaithAcks)

    ## 0x15000053 7
    def gnpu_ocfg_full_scan(self, WaithAcks=0):
        self.pcie_ocfg_cube(0, 0, op=7, WaithAcks=WaithAcks)

    ## 0x15000053 8
    def gnpu_ocfg_clrs(self, addr, leng=1, WaithAcks=0):
        self.pcie_ocfg_cube(addr, leng, op=8, WaithAcks=WaithAcks)

    ## 0x15000053 9
    def gnpu_ocfg_copy(self, addr, addr2, leng, dma=0, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.pcie_cube_cmnd(LLMB_OCFG_CMND,    2, addr2, dma, 0,    addr, leng, 9, 0x15000053,    portMsk=portMsk)

    ## 0x15000054 2
    def gnpu_icfg_epdc(self, addr, WaithAcks=0):
        data = self.pcie_icfg_cube(addr, 0, op=2, WaithAcks=WaithAcks)
        return data

    ## 0x15000054 7
    def gnpu_icfg_full_scan(self, WaithAcks=0):
        data = self.pcie_icfg_cube(0, 0, op=7, WaithAcks=WaithAcks)
        return data

    ## 0x15000055
    def risv_writ_conf(self, addr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"risv_writ_conf addr={hex(addr)} data={hex(data)}")
        self.gnpu_natv_func(addr, data, 0, 0x15000055)
   
    ## 0x15000056
    def risv_read_conf(self, addr, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        res = self.gnpu_natv_func(addr, 0, 0, 0x15000056, resp=1, func=LLMB_ICFG_CMND)
        self.DEBUG4(f"risv_read_conf addr={hex(addr)} res={hex_str(res)}")
        return res
   
    ## 0x18000000
    def gnpu_writ_id(self):
        for i in range(PILE_NUM):
            for j in range(EDGE_NUM):
                edge = i * EDGE_NUM + j
                if edge >= TOTAL_GNPU//2:
                    break
                portMsk = ((2**i) << 16) | (2**j)
                self.DEBUG6(f"gnpu_writ_id {edge}")
                self.pcie_proc_nnex(2*edge, 0, 0, 0x18000000, portMsk)
   
    ## 0x18c00002
    def gnpu_writ_gpdr(self, vectAddr, spotAddr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG4(f"gnpu_writ_gpdr vectAddr={hex(vectAddr)}, spotAddr={hex(spotAddr)} data={hex(data)}")
        self.pcie_proc_nnex(vectAddr, spotAddr, data, 0x18c00002, portMsk)
   
    ## 0x18c10002
    def gnpu_read_gpdr(self, vectAddr, spotAddr, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.pcie_proc_nnex(vectAddr, spotAddr, 0, 0x18c10002, portMsk)
        #res = self.gnpu_icfg_epdc(1)
        res = self.epdc_out_or_ddr(indx=1, gnpu=0, epdc=1)
        self.DEBUG4(f"gnpu_read_gpdr vectAddr={hex(vectAddr)} spotAddr={hex(spotAddr)} res={hex_str(res)}")
        return res
   
    ## 0x18c00004
    def gnpu_writ_conf(self, addr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG6(f"gnpu_writ_conf addr={hex(addr)} data={hex(data)}")
        self.pcie_proc_nnex(addr, 0, data, 0x18c00004, portMsk)
   
    ## 0x18c10004
    def gnpu_read_conf(self, addr, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.pcie_proc_nnex(addr, 0, 0, 0x18c10004, portMsk)
        #res = self.gnpu_icfg_epdc(1)
        res = self.epdc_out_or_ddr(indx=1, gnpu=0, epdc=1)
        self.DEBUG4(f"gnpu_read_conf addr={hex(addr)} res={hex_str(res)}")
        return res
   
    def epdc_out_or_ddr(self, indx, gnpu, epdc=0, ddrAddr=0x80002020):
        if epdc == 1:
            piles = self.pcie_icfg_cube(gnpu*0x1000 + 0x8000 + 0x34 + indx*4)
        else:
            if gnpu == 0:
                piles = self.pcie_icfg_cube(ddrAddr + indx*4)
            else:
                self.cube_ddrc_partsel(1, 0)
                piles = self.pcie_icfg_cube(ddrAddr + indx*4)
                self.cube_ddrc_partsel(0, 0)
        return piles

    ## 0x18fc0000
    def gnpu_reqs_idle(self):
        self.gnpu_nnex_func(aux0=0, aux1=0, aux2=0, aux3=0x18fc0000, portMsk=APAE, func=LLMB_OCFG_CMND)
   
    def ddrAddr2cpuAddrSel(self, ddrAddr, ddr):
        if ddrAddr >= 0x80000000:
            part = 1
            cpuAddr = ddrAddr
        else:
            part = 0
            cpuAddr = ddrAddr + 0x80000000
        self.cube_ddrc_partsel(ddr, part)
        return cpuAddr

    def check_share_mem(self, m=1, n=1, pause=0):
        SHARE_MEM = LAMA_RISV_PARA[m-1]['PARA']
        cpuAddr = self.ddrAddr2cpuAddrSel(SHARE_MEM*64, ddr=0)
        i = 0
        while n > 0:
            data = self.pcie_icfg_cube(cpuAddr + i*4, single=0)
            self.DEBUG4(f"SHARE{m}[{i}] = {hex_str(data)}")
            i = i + 1
            n = n - 1
        if pause == 1:
            input(f"pause")

    ##========================================
    
    def pcie_ocfg_mgth(self, sdes):
        self.DEBUG4(f"pcie_cfig_sdes")
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , sdes, 0, 0, 0);
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    
    def pcie_icfg_mgth (self, want):
        self.DEBUG4(f"pcie_icfg_mgth, for pcie to wait for sdes_dclk, serdes check link up")
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0);
        while 1:
            self.us_sleep(100)
            self.DEBUG4(f"---- ---- Waiting PILE sdes clock arise")
            self.pcie_issu_cmnd(LLMB_ICFG_CMND)
            rgs0 = self.PCIe_ReadCtrl(TPGS0_ACKS_DATA0, 1)
            rgs1 = self.PCIe_ReadCtrl(TPGS1_ACKS_DATA0, 1)
            rgs2 = self.PCIe_ReadCtrl(TPGS2_ACKS_DATA0, 1)
            rgs3 = self.PCIe_ReadCtrl(TPGS3_ACKS_DATA0, 1)
            self.DEBUG4(f"SDES STAT {hex(rgs0[0])} {hex(rgs1[0])} {hex(rgs2[0])} {hex(rgs3[0])}")
            if rgs0[0] == 0x3f0000 and rgs1[0] == 0x2b0000 and rgs2[0] == 0x2b0000 and rgs3[0] == 0x2b0000:
                break
    
    ##========================================
    
    def sdes_on(self):
        self.pcie_ocfg_mgth(0x15)
        self.ms_sleep(100)
        self.pcie_ocfg_mgth(0)
        self.ms_sleep(100)
        self.pcie_icfg_mgth(0xc)
 
    def tpgm_rism_tpgs(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_rism_tpgs master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} edge_rows={edge_rows}, edge_cols={edge_cols}, portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 5, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_RISM_CMND, HardAcks=issuHardAcks)

    def tpgm_rimt_tpes(self, slave_addr, master_addr, port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_rimt_tpes master={hex(master_addr)} slave={hex(slave_addr)} port_rows={port_rows} port_cols={port_cols} edge_rows={edge_rows} edge_cols={edge_cols} OP={hex(OP)} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, gsml, master_addr, slave_addr, port_rows, port_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        self.pcie_issu_cmnd(LLMB_RIMT_CMND, HardAcks=issuHardAcks)

    def tpgm_ivct_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_ivct_tpes master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} edge_rows={edge_rows} edge_cols={edge_cols} OP={hex(OP)} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, gsml, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        #input(f"LLMB_IVCT_CMND:")
        self.pcie_issu_cmnd(LLMB_IVCT_CMND, HardAcks=issuHardAcks)

    def tpgm_ovct_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_ovct_tpes master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} edge_rows={edge_rows} edge_cols={edge_cols} OP={hex(OP)} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, dvpx, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        #input(f"LLMB_OVCT_CMND:")
        #self.ms_sleep(1000)
        #self.ms_sleep(500)
        #self.ms_sleep(200)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND, HardAcks=issuHardAcks)

    def pcie_proc_nnex(self, LS, LC, LOOP, OP, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"pcie_proc_nnex LS={LS} LC={LC} LOOP={LOOP} OP={hex(OP)} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, NNEX, 0, 0, 0, 0, 0, 0, 0, 0, LS, LC, LOOP, OP)
        self.pcie_issu_cmnd(LLMB_NNEX_CMND, HardAcks=issuHardAcks)

    def tpgm_omtx_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_omtx_tpes meta_rows={meta_rows}")
        rows_md32 = meta_rows // 32
        rows_tile = rows_md32 * 32
        rows_left = meta_rows - rows_tile
        CustomRow = int(rows_tile * meta_cols / CustomCol)
        if rows_tile > 0:
            self.tpgm_omtx_tile(slave_addr, master_addr, rows_tile, meta_cols, CustomRow, CustomCol, OP, dvpx, portMsk)
        if rows_left > 0:
            mast_offset = rows_tile * meta_cols // 16
            slav_offset = mast_offset // 2
            master_addr = master_addr + mast_offset
            slave_addr = slave_addr + slav_offset
            left_cols = rows_left * 128
            left_rows = rows_left * meta_cols // left_cols
            self.tpgm_omtx_tile(slave_addr, master_addr, rows_left, meta_cols, left_rows, left_cols, OP, dvpx, portMsk)

    def tpgm_omtx_tile(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_omtx_tile master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} edge_rows={edge_rows} edge_cols={edge_cols} OP={hex(OP)} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 0, 0, dvpx, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        self.pcie_issu_cmnd(LLMB_OMTX_CMND, HardAcks=issuHardAcks)

    ##----------------------------------------
    
    def tpgm_ivct_tpgs(self, slave_addr, master_addr, meta_rows, meta_cols, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_ivct_tpgs master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_IVCT_CMND, HardAcks=issuHardAcks)

    def tpgm_ovct_tpgs(self, slave_addr, master_addr, meta_rows, meta_cols, portMsk=-1):
        if portMsk == -1:
            portMsk = APAE
        self.DEBUG5(f"tpgm_ovct_tpgs master={hex(master_addr)} slave={hex(slave_addr)} meta_rows={meta_rows} meta_cols={meta_cols} portMsk={hex(portMsk)}")
        self.pcie_cfig_cmnd(portMsk, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND, HardAcks=issuHardAcks)

